package platform.states;

import platform.DisplayJframe;
import platform.GameSettings;
import platform.entities.Corner;
import platform.entities.Player;
import platform.entities.Side;
import platform.entities.Tile;
import platform.render.ModelManager;
import platform.render.SideView;
import platform.utils.CustomButton;
import platform.utils.Ressources;

import java.awt.*;
import java.util.ArrayList;

public class ProgressState extends GameState{
    private static final String[] tmp1={"lumbercard","brickcard","wheatcard","sheepcard","orecard"};
    private static final Ressources[] tmp2={Ressources.LUMBER,Ressources.BRICK,Ressources.WHEAT,Ressources.SHEEP,Ressources.ORE};

    protected GameSettings settings;
    protected StateView sideview;
    protected Player currentPlayer;


    public ProgressState(GameStateManager gsm, GameSettings settings, Player player) {
        super(gsm);
        this.settings=settings;
        this.currentPlayer=player;
        sideview =new StateView(gsm,settings,player);
        init();
        System.out.println("[GameStates][monopoly State]: Creating steal state...");
    }

    public void init(){}


    @Override
    public void render(Graphics graphics) {
        for (Tile block : settings.map.getBlocks()) {
            block.render(graphics);
        }
        for (Corner corner : settings.map.getCorners()) {
            corner.render(graphics);
        }
        for (Side side : settings.map.getSides()) {
            side.render(graphics);
        }
        //drawing side bars_________
        sideview.render(graphics);
    }


    @Override
    public void keyPressed(int key) {}
    @Override
    public void keyReleased(int key) {}
    @Override
    public void mouseClicked( int x, int y) {
        sideview.mouseClicked(x,y);
    }
    @Override
    public void mouseMoved( int x, int y) {
        sideview.mouseMoved(x,y);
    }
    @Override
    public void mousePressed( int x, int y) {
        sideview.mousePressed(x,y);
    }
    @Override
    public void mouseReleased( int x, int y) {
        sideview.mouseReleased(x,y);
    }



    public static class StateView extends SideView {
        private Rectangle choicebar;
        private ArrayList<CustomButton> Ressourcesuttons=new ArrayList<>();

        public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer) {
            super(gsm, settings, currentPlayer);
            choicebar=new Rectangle(0, DisplayJframe.HEIGHT - 2*bottomBar.height, DisplayJframe.WIDTH-sideBar.width, bottomBar.height);
            initPlayerButtons();
        }

        private void initPlayerButtons() {
            int w = 33;
            int h = 50;
            int xStart = choicebar.x+10;
            int yStart = choicebar.y+10;
            int xOffset = (int) (w * 1.1f);

            for (int i=0;i<5;i++) {
                Ressourcesuttons.add(new CustomButton(ModelManager.getmodel(tmp1[i]),tmp1[i],xStart - xOffset * i,yStart,w,h));
                i++;
            }
        }

        @Override
        public void render(Graphics graphics) {
            super.render(graphics);
            // choice bar
            graphics.setColor(new Color(91, 104, 108));
            graphics.fillRect(choicebar.x,choicebar.y,choicebar.width,choicebar.height);
            // CustomButtons
            for(CustomButton pb : Ressourcesuttons) pb.render(graphics);
        }

        @Override
        public void mouseClicked(int x, int y){
            super.mouseClicked(x,y);
            for(CustomButton pb : Ressourcesuttons){
                if(pb.contains(x,y)){
                    int index=Ressourcesuttons.indexOf(pb);
                    Ressources r=tmp2[index];
                    currentPlayer.getInventory().addRessource(r);
                    this.gsm.removeState();
                    return;
                }
            }
        }

        public void skip(){}
        public void roll(){}
        public void buy(){}
        public void build(){}
        public void upgrade(){}
        public void road(){}
    }
}

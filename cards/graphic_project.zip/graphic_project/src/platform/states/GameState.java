package platform.states;

import platform.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public abstract class GameState extends JPanel {

	protected GameStateManager gsm;
	
	//Creates game state
	public GameState(GameStateManager gsm) {
		this.gsm = gsm;
	}

	public void init() {}

	public abstract void render(Graphics graphics);
	
	public abstract void keyPressed(int key);
	
	public abstract void keyReleased(int key);

	public void applyStrategy(){}

	
	public abstract void mouseMoved( int x, int y);
	 
	public abstract void mouseClicked( int x, int y);
	
	public abstract void mousePressed( int x, int y);
	
	public abstract void mouseReleased( int x, int y);

	public void mouseDragged( int x, int y){}
	
	public void mouseEntered( int x, int y){}
	 
	public void mouseExited( int x, int y){}

	public GameStateManager getGsm() {
		return gsm;
	}
}

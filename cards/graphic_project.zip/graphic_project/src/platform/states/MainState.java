package platform.states;


import platform.GameSettings;
import platform.entities.*;
import platform.render.Renderer;
import platform.render.SideView;
import platform.utils.Ressources;

import java.awt.Graphics;
import java.util.Random;

public class MainState extends GameState {

	protected GameSettings settings;
	protected StateView sideview;
	protected Player currentPlayer;

	public MainState(GameStateManager gsm, GameSettings settings,Player player) {
		super(gsm);
		this.settings=settings;
		this.currentPlayer=player;
		sideview =new StateView(gsm,settings,player);
		sideview.roll.setActive(true);
		System.out.println("[GameStates][MainState]: Creating Main state...");
		init();
	}

	@Override
	public void init(){}

	public void applyStrategy(){
		currentPlayer.applyStrategy(this);
	}

	@Override
	public void render(Graphics graphics) {
		for (Tile block : settings.map.getBlocks()) {
			block.render(graphics);
			if(block.getType()!= Ressources.SEA && block.getType()!=Ressources.DESERT) block.getModel().drawTextInCenter(block.getLable()+"");
		}
		for (Corner corner : settings.map.getCorners()) {
			corner.render(graphics);
		}
		for (Side side : settings.map.getSides()) {
			side.render(graphics);
		}
		sideview.render(graphics);
	}

	@Override
	public void keyPressed(int key) {}
	@Override
	public void keyReleased(int key) {}
	@Override
	public void mouseMoved( int x, int y) {sideview.mouseMoved(x,y);}
	@Override
	public void mouseClicked( int x, int y) {sideview.mouseClicked(x,y);}
	@Override
	public void mousePressed( int x, int y) {sideview.mousePressed(x,y);}
	@Override
	public void mouseReleased( int x, int y) {sideview.mouseReleased(x,y);}

	public StateView getSideview() {
		return sideview;
	}

	public GameSettings getSettings() {
		return settings;
	}

	public static class StateView extends SideView {
		public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer) {
			super(gsm, settings, currentPlayer);
		}

		public void skip(){
			this.gsm.removeState();
			this.gsm.addState(new MainState(gsm,settings,currentPlayer.getNext()));
			this.gsm.applyStrategy();
		}
		public void roll(){
			Random r = new Random();
			setDice(r.nextInt(6)+1,r.nextInt(6)+1);
			int diceres=getDice();
			if(diceres==7){
				this.gsm.addState(new PLaceRobberState(gsm,settings,currentPlayer));
			}else {
				for (Tile t : settings.map.getBlocks()) {
					if (t.getLable() == diceres && !t.hasStealer()) {
						t.harnessRessource();
					}
				}
			}
			setActive();
			roll.setActive(false);
		}
		public void buy(){
			if(currentPlayer.getInventory().canBuyDev()){
				currentPlayer.buyDevCard();
			}
		}
		public void build(){
			if(currentPlayer.getInventory().canBuildSettelment()) {
				this.gsm.addState(new PlaceSettelmentState(gsm, settings, currentPlayer));
			}
		}
		public void upgrade(){
			if(currentPlayer.getInventory().canBuildCity()) {
				this.gsm.addState(new PlaceCityState(gsm, settings, currentPlayer));
			}
		}
		public void road(){
			if(currentPlayer.getInventory().canBuildRoad()) {
				this.gsm.addState(new PlaceRoadState(gsm, settings, currentPlayer));
			}
		}
	}


}
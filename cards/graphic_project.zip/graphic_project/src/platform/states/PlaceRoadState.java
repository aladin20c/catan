package platform.states;

import platform.GameSettings;
import platform.entities.Corner;
import platform.entities.Player;
import platform.entities.Side;
import platform.entities.Tile;
import platform.render.SideView;
import platform.utils.Select;

import java.awt.*;
import java.util.ArrayList;

public class PlaceRoadState extends GameState{
    protected GameSettings settings;
    protected StateView sideview;
    protected Player currentPlayer;
    protected ArrayList<Select<Side>> targetSides;


    public PlaceRoadState(GameStateManager gsm, GameSettings settings,Player player) {
        super(gsm);
        this.settings=settings;
        this.currentPlayer=player;
        sideview =new StateView(gsm,settings,player);
        sideview.road.setActive(true);
        init();
        System.out.println("[GameStates][Place road State]: Creating place road state...");
    }

    public void init(){
        targetSides=new ArrayList<>();
        for (Side side : currentPlayer.getPotentialRoads())
            targetSides.add(new Select<Side>((side.corner_1.getPosX()+side.corner_2.getPosX())/2,(side.corner_1.getPosY()+side.corner_2.getPosY())/2,30,side));
    }


    @Override
    public void render(Graphics graphics) {
        for (Tile block : settings.map.getBlocks()) {
            block.render(graphics);
        }
        for (Corner corner : settings.map.getCorners()) {
            corner.render(graphics);
        }
        for (Side side : settings.map.getSides()) {
            side.render(graphics);
        }
        //drawing targets_________
        for (Select s : targetSides) s.render(graphics);

        //drawing side bars_________
        sideview.render(graphics);
    }


    @Override
    public void keyPressed(int key) {}
    @Override
    public void keyReleased(int key) {}
    @Override
    public void mouseClicked( int x, int y) {
        sideview.mouseClicked(x,y);

        for (Select<Side> s : targetSides) {
            if (s.contains(x, y)) {
                s.getEntity().setRoad(currentPlayer);
                currentPlayer.getInventory().cutRoadMaterial();
                this.gsm.removeState();
                return;
            }
        }
    }
    @Override
    public void mouseMoved( int x, int y) {
        sideview.mouseMoved(x,y);
        for (Select s : targetSides) s.setMouseOver(false);
        for (Select s : targetSides) {
            if (s.contains(x, y)) {
                s.setMouseOver(true);
                return;
            }
        }
    }
    @Override
    public void mousePressed( int x, int y) {
        sideview.mousePressed(x,y);
        for (Select s : targetSides) {
            if (s.contains(x, y)) {
                s.setMousePressed(true);
                return;
            }
        }
    }
    @Override
    public void mouseReleased( int x, int y) {
        sideview.mouseReleased(x,y);

        for (Select s : targetSides) {
            s.resetBooleans();
        }
    }

    public static class StateView extends SideView {
        public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer) {
            super(gsm, settings, currentPlayer);
        }
        public void skip(){}
        public void roll(){}
        public void buy(){}
        public void build(){}
        public void upgrade(){}
        public void road(){
            this.gsm.removeState();
        }
    }
}

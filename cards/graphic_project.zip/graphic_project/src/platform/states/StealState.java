package platform.states;

import platform.DisplayJframe;
import platform.GameSettings;
import platform.entities.Corner;
import platform.entities.Player;
import platform.entities.Side;
import platform.entities.Tile;
import platform.render.ModelManager;
import platform.render.SideView;
import platform.utils.CustomButton;
import platform.utils.Ressources;
import platform.utils.Select;

import java.awt.*;
import java.util.ArrayList;

public class StealState extends GameState{

    protected GameSettings settings;
    protected StateView sideview;
    protected Player currentPlayer;
    protected ArrayList<Player> players;


    public StealState(GameStateManager gsm, GameSettings settings, Player player,ArrayList<Player> players) {
        super(gsm);
        this.settings=settings;
        this.currentPlayer=player;
        this.players=players;
        if(players==null || players.size()==0){
            this.gsm.removeState();
            this.gsm.removeState();
        }
        sideview =new StateView(gsm,settings,player,players);
        init();
        System.out.println("[GameStates][steal State]: Creating steal state...");
    }

    public void init(){}


    @Override
    public void render(Graphics graphics) {
        for (Tile block : settings.map.getBlocks()) {
            block.render(graphics);
        }
        for (Corner corner : settings.map.getCorners()) {
            corner.render(graphics);
        }
        for (Side side : settings.map.getSides()) {
            side.render(graphics);
        }
        //drawing side bars_________
        sideview.render(graphics);
    }


    @Override
    public void keyPressed(int key) {}
    @Override
    public void keyReleased(int key) {}
    @Override
    public void mouseClicked( int x, int y) {
        sideview.mouseClicked(x,y);
    }
    @Override
    public void mouseMoved( int x, int y) {
        sideview.mouseMoved(x,y);
    }
    @Override
    public void mousePressed( int x, int y) {
        sideview.mousePressed(x,y);
    }
    @Override
    public void mouseReleased( int x, int y) {
        sideview.mouseReleased(x,y);
    }



    public static class StateView extends SideView {
        private Rectangle choicebar;
        private ArrayList<Player> players;
        private ArrayList<CustomButton> playerButtons;

        public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer,ArrayList<Player> players) {
            super(gsm, settings, currentPlayer);
            this.players=players;
            choicebar=new Rectangle(0, DisplayJframe.HEIGHT - 2*bottomBar.height, DisplayJframe.WIDTH-sideBar.width, bottomBar.height);
            initPlayerButtons();
        }

        private void initPlayerButtons() {
            playerButtons=new ArrayList<>();
            int w = 50;
            int h = 50;
            int xStart = choicebar.x+100;
            int yStart = choicebar.y+10;
            int xOffset = (int) (w * 1.1f);

            for (int i=0;i<players.size();i++) {
                Player p=players.get(i);
                playerButtons.add(new CustomButton(p.getModule(),p.name,xStart + xOffset * i,yStart,w,h));
                i++;
            }
        }

        @Override
        public void render(Graphics graphics) {
            super.render(graphics);
            // choice bar
            graphics.setColor(new Color(231, 219, 193));
            graphics.fillRect(choicebar.x,choicebar.y,choicebar.width,choicebar.height);
            // CustomButtons

            graphics.setColor(new Color(218, 10, 58));
            for(CustomButton pb : playerButtons) pb.render(graphics);
        }

        @Override
        public void mouseClicked(int x, int y){
            super.mouseClicked(x,y);
            for(CustomButton pb : playerButtons){
                if(pb.contains(x,y)){
                    int index=playerButtons.indexOf(pb);
                    Player playerClicked=players.get(index);
                    playerClicked.giveCardTo(currentPlayer);
                    this.gsm.removeState();
                    this.gsm.removeState();
                }
            }
        }

        public void skip(){}
        public void roll(){}
        public void buy(){}
        public void build(){}
        public void upgrade(){}
        public void road(){}
    }

}

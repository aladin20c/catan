package platform.states;

import platform.GameSettings;
import platform.entities.*;
import platform.render.SideView;
import platform.utils.Select;
import java.awt.*;
import java.util.ArrayList;

public class FirstMoveState extends GameState{
    protected GameSettings settings;
    protected StateView sideview;
    protected Player currentPlayer;
    protected ArrayList<Select<Corner>> targetCorners;
    public boolean getRessources=false;


    public FirstMoveState(GameStateManager gsm, GameSettings settings,Player player) {
        super(gsm);
        this.settings=settings;
        this.currentPlayer=player;
        sideview =new StateView(gsm,settings,player);
        init();
        System.out.println("[GameStates][FirstMoveState]: Creating first move state...");
    }
    public FirstMoveState(GameStateManager gsm, GameSettings settings,Player player,boolean getRessources) {
        this(gsm,settings,player);
        this.getRessources=getRessources;
    }


    public void init(){
        targetCorners=new ArrayList<>();
        for (Corner corner : settings.map.getCorners()) {
            if(corner.isBuildable()){
                targetCorners.add(new Select<Corner>(corner.getPosX(),corner.getPosY(),30,corner));
            }
        }
    }
    public void applyStrategy(){
        currentPlayer.applyStrategy(this);
    }
    @Override
    public void render(Graphics graphics) {
        for (Tile block : settings.map.getBlocks()) {
            block.render(graphics);
        }
        for (Corner corner : settings.map.getCorners()) {
            corner.render(graphics);
        }
        for (Side side : settings.map.getSides()) {
            side.render(graphics);
        }
        //drawing targets_________
        for (Select s : targetCorners) s.render(graphics);

        //drawing side bars_________
        sideview.render(graphics);
    }


    @Override
    public void keyPressed(int key) {}
    @Override
    public void keyReleased(int key) {}
    @Override
    public void mouseClicked( int x, int y) {
        sideview.mouseClicked(x,y);
            for (Select<Corner> s : targetCorners) {
                if (s.contains(x, y)) {
                    s.getEntity().ForceSetSettlement(currentPlayer);
                    if(getRessources)s.getEntity().harnessAdjascentTiles();
                    this.gsm.removeState();
                    return;
                }
            }
    }
    @Override
    public void mouseMoved( int x, int y) {
        sideview.mouseMoved(x,y);
        for (Select s : targetCorners) s.setMouseOver(false);
        for (Select s : targetCorners) {
            if (s.contains(x, y)) {
                s.setMouseOver(true);
                return;
            }
        }
    }
    @Override
    public void mousePressed( int x, int y) {
        sideview.mousePressed(x,y);
        for (Select s : targetCorners) {
            if (s.contains(x, y)) {
                s.setMousePressed(true);
                return;
            }
        }
    }
    @Override
    public void mouseReleased( int x, int y) {
        sideview.mouseReleased(x,y);

        for (Select s : targetCorners) {
            s.resetBooleans();
        }
    }

    public ArrayList<Select<Corner>> getTargetCorners() {
        return targetCorners;
    }

    public GameSettings getSettings() {
        return settings;
    }

    public static class StateView extends SideView{
        public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer) {
            super(gsm, settings, currentPlayer);
        }
        public void skip(){}
        public void roll(){}
        public void buy(){}
        public void build(){}
        public void upgrade(){}
        public void road(){}
    }

}

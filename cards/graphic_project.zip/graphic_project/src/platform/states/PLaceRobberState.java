package platform.states;

import platform.GameSettings;
import platform.entities.*;
import platform.render.SideView;
import platform.utils.Ressources;
import platform.utils.Select;

import java.awt.*;
import java.util.ArrayList;

public class PLaceRobberState extends GameState{

    protected GameSettings settings;
    protected StateView sideview;
    protected Player currentPlayer;
    protected ArrayList<Select<Tile>> targetTiles;


    public PLaceRobberState(GameStateManager gsm, GameSettings settings,Player player) {
        super(gsm);
        this.settings=settings;
        this.currentPlayer=player;
        sideview =new StateView(gsm,settings,player);
        init();
        System.out.println("[GameStates][Place Robber State]: Creating place Robber state...");
    }

    public void init(){
        targetTiles=new ArrayList<>();
        for (Tile tile : settings.map.getBlocks()) {
            if(tile.getType()!= Ressources.SEA && tile.getType()!= Ressources.DESERT && !tile.hasStealer()) {
                int x=(tile.corners[Map.top_left].getPosX()+tile.corners[Map.bottom_right].getPosX())/2;
                int y=(tile.corners[Map.top_left].getPosY()+tile.corners[Map.bottom_right].getPosY())/2;
                targetTiles.add(new Select<Tile>(x, y, 30, tile));
            }
        }
    }


    @Override
    public void render(Graphics graphics) {
        for (Tile block : settings.map.getBlocks()) {
            block.render(graphics);
        }
        for (Corner corner : settings.map.getCorners()) {
            corner.render(graphics);
        }
        for (Side side : settings.map.getSides()) {
            side.render(graphics);
        }
        //drawing targets_________
        for (Select s : targetTiles) s.render(graphics);

        //drawing side bars_________
        sideview.render(graphics);
    }


    @Override
    public void keyPressed(int key) {}
    @Override
    public void keyReleased(int key) {}
    @Override
    public void mouseClicked( int x, int y) {
        sideview.mouseClicked(x,y);

        for (Select<Tile> s : targetTiles) {
            if (s.contains(x, y)) {
                for(Tile tile : settings.map.getBlocks()){
                    tile.setStealer(false);
                }
                s.getEntity().setStealer(true);
                ArrayList<Player> arg=new ArrayList<>();
                for(Player p : s.getEntity().getOwners()){
                    if(p!=currentPlayer) arg.add(p);
                }
                if(arg.isEmpty())this.gsm.removeState();
                else this.gsm.addState(new StealState(gsm,settings,currentPlayer,arg));
                return;
            }
        }
    }
    @Override
    public void mouseMoved( int x, int y) {
        sideview.mouseMoved(x,y);
        for (Select s : targetTiles) s.setMouseOver(false);
        for (Select s : targetTiles) {
            if (s.contains(x, y)) {
                s.setMouseOver(true);
                return;
            }
        }
    }
    @Override
    public void mousePressed( int x, int y) {
        sideview.mousePressed(x,y);
        for (Select s : targetTiles) {
            if (s.contains(x, y)) {
                s.setMousePressed(true);
                return;
            }
        }
    }
    @Override
    public void mouseReleased( int x, int y) {
        sideview.mouseReleased(x,y);

        for (Select s : targetTiles) {
            s.resetBooleans();
        }
    }




    public static class StateView extends SideView {
        public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer) {
            super(gsm, settings, currentPlayer);
        }
        public void skip(){}
        public void roll(){}
        public void buy(){}
        public void build(){}
        public void upgrade(){}
        public void road(){}
    }
}

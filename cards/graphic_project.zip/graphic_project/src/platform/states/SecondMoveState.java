package platform.states;

import platform.GameSettings;
import platform.entities.Corner;
import platform.entities.Player;
import platform.entities.Side;
import platform.entities.Tile;
import platform.render.SideView;
import platform.utils.Select;

import java.awt.*;
import java.util.ArrayList;

public class SecondMoveState extends GameState{
    protected GameSettings settings;
    protected StateView sideview;
    protected Player currentPlayer;
    protected ArrayList<Select<Side>> targetSides=new ArrayList<>();



    public SecondMoveState(GameStateManager gsm, GameSettings settings,Player player) {
        super(gsm);
        this.settings=settings;
        sideview =new StateView(gsm,settings,player);
        this.currentPlayer=player;
        init();
        System.out.println("[GameStates][SecondMoveState]: Creating second move state...");
    }

    public void init(){
        for(Corner c: currentPlayer.settelments){
            if(c.isIsolated()) {
                for (Side side : c.getAdjascentSides()) {
                    targetSides.add(new Select<Side>((side.corner_1.getPosX()+side.corner_2.getPosX())/2,(side.corner_1.getPosY()+side.corner_2.getPosY())/2,30,side));
                }
                return;
            }
        }
    }

    public void applyStrategy(){
        currentPlayer.applyStrategy(this);
    }

    @Override
    public void render(Graphics graphics) {
        for (Tile block : settings.map.getBlocks()) {
            block.render(graphics);
        }
        for (Corner corner : settings.map.getCorners()) {
            corner.render(graphics);
        }
        for (Side side : settings.map.getSides()) {
            side.render(graphics);
        }
        //drawing targets_________
        for (Select s : targetSides) s.render(graphics);

        //drawing side bars_________
        sideview.render(graphics);
    }


    @Override
    public void keyPressed(int key) {}
    @Override
    public void keyReleased(int key) {}

    @Override
    public void mouseClicked( int x, int y) {
        sideview.mouseClicked(x,y);

        for (Select<Side> s : targetSides) {
            if (s.contains(x, y)) {
                s.getEntity().setRoad(currentPlayer);
                this.gsm.removeState();
                return;
            }
        }
    }

    @Override
    public void mouseMoved( int x, int y) {
        sideview.mouseMoved(x,y);
        for (Select s : targetSides) s.setMouseOver(false);
        for (Select s : targetSides) {
            if (s.contains(x, y)) {
                s.setMouseOver(true);
                return;
            }
        }
    }

    @Override
    public void mousePressed( int x, int y) {
        sideview.mousePressed(x,y);
        for (Select s : targetSides) {
            if (s.contains(x, y)) {
                s.setMousePressed(true);
                return;
            }
        }
    }

    @Override
    public void mouseReleased( int x, int y) {
        sideview.mouseReleased(x,y);

        for (Select s : targetSides) {
            s.resetBooleans();
        }
    }

    public ArrayList<Select<Side>> getTargetSides() {
        return targetSides;
    }

    public GameSettings getSettings() {
        return settings;
    }

    public static class StateView extends SideView {
        public StateView(GameStateManager gsm, GameSettings settings, Player currentPlayer) {
            super(gsm, settings, currentPlayer);
        }
        public void skip(){}
        public void roll(){}
        public void buy(){}
        public void build(){}
        public void upgrade(){}
        public void road(){}
    }


}

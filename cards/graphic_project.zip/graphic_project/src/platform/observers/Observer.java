package platform.observers;

public interface Observer {

    public abstract void inform();
}

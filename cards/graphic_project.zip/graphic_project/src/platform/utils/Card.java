package platform.utils;

import java.util.Objects;

public class Card {

    public static final String vp ="vp";
    public static final String robber="robber";
    public static final String progress="progress";
    public static final String expansion="expansion";
    public static final String monopoly="monopoly";

    private String name;

    public Card(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Card)) return false;
        Card card = (Card) o;
        return Objects.equals(name, card.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public String getName() {
        return name;
    }
}

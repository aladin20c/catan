package platform.utils;

public enum Direction {
    HOEIZENTAL,VERTICAL;
}

package platform.utils;

public enum Ressources {

	EMPTY,BRICK, LUMBER, WHEAT, SHEEP, ORE,DESERT,SEA;

}

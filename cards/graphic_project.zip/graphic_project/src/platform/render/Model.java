package platform.render;


import platform.utils.ImageUtil;

import java.awt.*;
import java.awt.image.BufferedImage;


public class Model extends Rectangle {
	private BufferedImage image;


	public Model(int w, int h) {
		super(w, h);
		this.image = null;
	}
	public Model(String fileName) {
		this.image= ImageUtil.loadImage(fileName);
		this.width = image.getWidth();
		this.height=image.getHeight();
	}
	public Model(BufferedImage image) {
		super(image.getWidth(), image.getHeight());
		this.image = image;
	}
	public Model(int width, int height, String fileName) {
		super(width, height);
		this.image= ImageUtil.loadImage(width,height,fileName);
	}
	public Model(int w, int h, BufferedImage image) {
		super(w, h);
		this.image = image;
	}



	public void drawTextInCenter(String text){
		Graphics g = image.getGraphics();
		FontMetrics metrics = g.getFontMetrics();
		int positionX = (image.getWidth() - metrics.stringWidth(text)) / 2;
		int positionY = (image.getHeight() - metrics.getHeight()) / 2 + metrics.getAscent();

		Font font = new Font("Arial", Font.BOLD, 25);
		g.setFont(font);
		g.setColor(Color.BLACK);
		g.drawString(text, positionX, positionY);
	}


	public BufferedImage getImage() {return image;}
	public void setImage(BufferedImage image) {this.image = image;}

}

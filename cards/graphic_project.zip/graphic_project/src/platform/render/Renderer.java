package platform.render;



import platform.entities.StaticEntity;

import java.awt.*;

public class Renderer {

	/**Renders an entity on screen
	 * @param entity - The entity to render
	 * @param graphics - Graphics object
	 */
	public static void renderEntity(StaticEntity entity, Graphics graphics) {
		if(entity.hasModel()) renderModel(entity.getModel(), entity.getPosX(), entity.getPosY(), graphics);
	}
	
	/**Renders a model on screen
	 * @param model - The model to render
	 * @param posX - Model top left corner position
	 * @param posY - Model top left corner position
	 * @param graphics - Graphics object
	 */
	public static void renderModel(Model model, int posX, int posY, Graphics graphics) {
		graphics.drawImage(model.getImage(), posX, posY, model.width, model.height, null);
	}

}

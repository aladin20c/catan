package platform.render;

import platform.DisplayJframe;
import platform.GameSettings;
import platform.entities.Player;
import platform.states.*;
import platform.utils.Card;
import platform.utils.CustomButton;
import platform.utils.Ressources;

import java.awt.*;
import java.util.ArrayList;


public abstract class SideView{

	private final static Ressources[] ressources={Ressources.LUMBER,Ressources.BRICK,Ressources.WHEAT,Ressources.SHEEP,Ressources.ORE};
	protected GameStateManager gsm;
	protected GameSettings settings;
	protected Player currentPlayer;

	public CustomButton exit;
	public CustomButton skip;
	public CustomButton roll;
	public CustomButton buy;
	public CustomButton build;
	public CustomButton upgrade;
	public CustomButton road;

	protected ArrayList<CustomButton> controls = new ArrayList<>();
	protected ArrayList<CustomButton> devcards = new ArrayList<>();
	protected Rectangle bottomBar;
	protected Rectangle sideBar;


	public SideView(GameStateManager gsm,GameSettings settings,Player currentPlayer) {
		this.gsm=gsm;
		this.settings=settings;
		this.currentPlayer=currentPlayer;
		bottomBar=new Rectangle(0, DisplayJframe.HEIGHT - 90, DisplayJframe.WIDTH, 90);
		sideBar=new Rectangle(DisplayJframe.WIDTH-90, 0, 90, DisplayJframe.HEIGHT-90);
		initControls();
	}
	private void initControls() {
		exit = new CustomButton("exit");controls.add(exit);
		skip= new CustomButton("skip");controls.add(skip);
		roll= new CustomButton("roll");controls.add(roll);
		buy= new CustomButton("buy");controls.add(buy);
		build= new CustomButton(ModelManager.getmodel(ModelManager.SETTELMENT),"build");controls.add(build);
		upgrade= new CustomButton(ModelManager.getmodel(ModelManager.CITY),"upgrade");controls.add(upgrade);
		road= new CustomButton(ModelManager.getmodel(ModelManager.ROAD),"road");controls.add(road);
		int w = 50;
		int h = 50;
		int xStart = bottomBar.x+ bottomBar.width-w;
		int yStart = bottomBar.y+10;
		int xOffset = (int) (w * 1.1f);

		int i = 0;
		for (CustomButton b : controls) {
			b.setBounds( xStart - xOffset * i, yStart, w, h);
			i++;
		}
		setInactive();

	}
	public void initDevCards(){
		int i=6;
		int h = 50;
		int w=33;
		for(Card c: currentPlayer.getInventory().getExistingCards()){
			CustomButton cb= new CustomButton(ModelManager.getmodel(c.getName()),c.getName());
			cb.setBounds(bottomBar.x+ i * 40,bottomBar.y+10,w,h);
			devcards.add(cb);
			i++;
		}
	}



	public void render(Graphics graphics) {
		// Background
		graphics.setColor(new Color(24, 34, 37));
		graphics.fillRect(bottomBar.x,bottomBar.y,bottomBar.width,bottomBar.height);
		graphics.fillRect(sideBar.x,sideBar.y,sideBar.width,sideBar.height);
		// CustomButtons
		for(CustomButton b : controls) b.render(graphics);

		//Ressources
		String[] models={ModelManager.LUMBERCARD,ModelManager.BRICKCARD,ModelManager.WHEATCARD,ModelManager.SHEEPCARD,ModelManager.ORECARD};
		for (int i = 0; i < 5; i++) {
			Model model=ModelManager.getmodel(models[i]);
			Renderer.renderModel(model, 5+bottomBar.x+ i * 40, bottomBar.y+10, graphics);
			String txt=currentPlayer.getInventory().count(ressources[i])+"";
			drawTextInBottomRight(txt,5+bottomBar.x+ i * 40,bottomBar.y+10, graphics,model);
		}


		//DevCards
		initDevCards();
		for (CustomButton cb : devcards) {
			cb.render(graphics);
			Card c=new Card(cb.getName());
			drawTextInBottomRight(currentPlayer.getInventory().count(c)+"",graphics,cb);
		}


		//Players rendering
		for (int i = 0; i < settings.getPlayers().length; i++) {
			int x=sideBar.x+ 30;
			int y=sideBar.y+ i * 80+30;
			Rectangle rec=new Rectangle(x-10,y-10,settings.getPlayers()[i].getModule().width+20,settings.getPlayers()[i].getModule().height+20);

			if(settings.getPlayers()[i]==currentPlayer) {
				graphics.setColor(Color.gray);
				graphics.fillRect(rec.x,rec.y,rec.width,rec.height);
			}
			Model m=settings.getPlayers()[i].getModule();
			Renderer.renderModel(m,x,y, graphics);
			//drawTextInBottomRight(""+settings.getPlayers()[i].getVP(),graphics,rec);
			//graphics.setFont(new Font("Arial", Font.PLAIN, 15));
			//graphics.drawString("res:"+"cards:", 200, 150);
		}

		//Dice rendering
		int y_dice= DisplayJframe.HEIGHT-bottomBar.height-60;
		int x_dice_1=DisplayJframe.WIDTH-sideBar.width-120;
		int x_dice_2=DisplayJframe.WIDTH-sideBar.width-60;
		Renderer.renderModel(ModelManager.getmodel( "de"+settings.getDice1()), x_dice_1, y_dice, graphics);
		Renderer.renderModel(ModelManager.getmodel( "de"+settings.getDice2()), x_dice_2, y_dice, graphics);
	}


	public static void drawTextInBottomRight(String text,int x,int y,Graphics graphics,Model module){

		FontMetrics metrics = graphics.getFontMetrics();
		int positionX = (int)(x+(module.getWidth() - metrics.stringWidth(text)-4));
		int positionY = (int)(y+(module.getHeight() - metrics.getHeight()) + metrics.getAscent()-2);

		Font font = new Font("Arial", Font.BOLD, 20);
		graphics.setFont(font);
		graphics.setColor(Color.WHITE);
		graphics.drawString(text, positionX, positionY);
	}
	public static void drawTextInBottomRight(String text,Graphics graphics,Rectangle rec){

		FontMetrics metrics = graphics.getFontMetrics();
		int positionX = (int)(rec.x+(rec.getWidth() - metrics.stringWidth(text)-4));
		int positionY = (int)(rec.y+(rec.getHeight() - metrics.getHeight()) + metrics.getAscent()-2);

		Font font = new Font("Arial", Font.BOLD, 20);
		graphics.setFont(font);
		graphics.setColor(Color.WHITE);
		graphics.drawString(text, positionX, positionY);
	}






	public void mouseClicked(int x, int y){
		if (exit.contains(x, y) && exit.isActive()) {
			exit();
		}else if(skip.contains(x, y) && skip.isActive()){
			skip();
		}else if(roll.contains(x, y) && roll.isActive()){
			roll();
		}else if(buy.contains(x, y) && buy.isActive()){
			buy();
		}else if(build.contains(x, y) && build.isActive()){
			build();
		}else if(upgrade.contains(x, y) && upgrade.isActive()){
			upgrade();
		}else if(road.contains(x, y) && road.isActive()){
			road();
		}else{
			for(CustomButton cb : devcards){
				if(cb.contains(x,y)){
					DevCardAction(cb);
					return;
				}
			}
		}

	}

	public void DevCardAction(CustomButton cb){
		switch (cb.getName()){
			case "expansion":
				currentPlayer.getInventory().removeCard(new Card(Card.expansion));
				this.gsm.addState(new ExpansionState(gsm,settings,currentPlayer));
				this.gsm.addState(new ExpansionState(gsm,settings,currentPlayer));
				break;
			case "robber":
				currentPlayer.getInventory().removeCard(new Card(Card.robber));
				this.gsm.addState(new PLaceRobberState(gsm,settings,currentPlayer));
				break;
			case "vp":
				currentPlayer.getInventory().removeCard(new Card(Card.vp));
				currentPlayer.increaseVP(1);
				break;
			case "monopoly":
				currentPlayer.getInventory().removeCard(new Card(Card.monopoly));
				this.gsm.addState(new MonopolyState(gsm,settings,currentPlayer));
				break;
			case "progress":
				currentPlayer.getInventory().removeCard(new Card(Card.progress));
				this.gsm.addState(new ProgressState(gsm,settings,currentPlayer));
				this.gsm.addState(new ProgressState(gsm,settings,currentPlayer));
				break;
		}
	}

	public void exit(){this.gsm.addState(new GameOver(gsm,settings));}
	public abstract void skip();
	public abstract void roll();
	public abstract void buy();
	public abstract void build();
	public abstract void upgrade();
	public abstract void road();

	public void mouseMoved(int x, int y) {
		for(CustomButton b:controls) {
			b.setMouseOver(false);
		}
		for(CustomButton b:controls) {
			if (b.contains(x, y)) {
				b.setMouseOver(true);
				return;
			}
		}
	}
	public void mousePressed(int x, int y) {
		for(CustomButton b:controls) {
			if (b.contains(x, y)) {
				b.setMousePressed(true);
				return;
			}
		}
	}
	public void mouseReleased(int x, int y) {
		for(CustomButton b:controls) {
			b.resetBooleans();
		}
	}
	public void setInactive(){
		for (CustomButton b: controls) b.setActive(false);
		for (CustomButton b: devcards) b.setActive(false);
		exit.setActive(true);
	}
	public void setActive(){
		for (CustomButton b: controls) b.setActive(true);
		for (CustomButton b: devcards) b.setActive(true);
	}

	public void setDice(int dice_1,int dice_2) {settings.setDice(dice_1,dice_2);}
	public int getDice() {return settings.getDice1()+settings.getDice2();}
}

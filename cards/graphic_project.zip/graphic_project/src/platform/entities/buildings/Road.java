package platform.entities.buildings;

import platform.entities.Player;

public class Road extends Building{
    public Road(Player owner) {
        super(owner);
    }
}

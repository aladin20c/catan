package platform.entities;

import platform.GameSettings;
import platform.render.ModelManager;
import platform.states.*;
import platform.utils.Select;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Human extends Player{
    public Human(String name, Color color) {
        super(name, color);
        if( color.equals(Color.GREEN ))this.module= ModelManager.getmodel("human_green");
        else if( color.equals(Color.BLUE ))this.module= ModelManager.getmodel("human_blue");
        else if( color.equals(Color.RED) ) this.module= ModelManager.getmodel("human_red");
        else if( color.equals(Color.YELLOW )) this.module= ModelManager.getmodel("human_yellow");
    }
    public boolean isHuman(){return true;}
    public boolean isBot(){return false;}

    public Bot dehumanize(){
        String name= this.name.replace("human","bot");
        Bot bot=new Bot(name,this.getColor());
        set(bot);
        return bot;
    }


    public void applyStrategy(MainState st){}
    public void applyStrategy(FirstMoveState st) {}
    public void applyStrategy(SecondMoveState st) {}
    public void applyStrategy(GameState st) {}
}

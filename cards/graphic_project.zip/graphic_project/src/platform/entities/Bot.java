package platform.entities;

import com.sun.tools.javac.Main;
import platform.GameSettings;
import platform.render.ModelManager;
import platform.states.*;
import platform.utils.Select;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;


public class Bot extends Player{
    public Bot(String name, Color color) {
        super(name, color);
            if( color.equals(Color.GREEN ))this.module= ModelManager.getmodel("bot_green");
            else if( color.equals(Color.BLUE))this.module= ModelManager.getmodel("bot_blue");
            else if( color.equals(Color.RED )) this.module= ModelManager.getmodel("bot_red");
            else if( color.equals(Color.YELLOW)) this.module= ModelManager.getmodel("bot_yellow");
    }
    public boolean isHuman(){return true;}
    public boolean isBot(){return false;}

    public void applyStrategy(MainState st) {
        Random r = new Random();
        MainState.StateView sv=st.getSideview();
        sv.setDice(r.nextInt(6)+1,r.nextInt(6)+1);
        int diceres=sv.getDice();

        if(diceres==7){
            //TODO
        }else {
            for (Tile t : st.getSettings().map.getBlocks()) {
                if (t.getLable() == diceres && !t.hasStealer()) {
                    t.harnessRessource();
                }
            }
        }

        while(this.getInventory().canBuildCity() && !getPotentialCities().isEmpty()){
            ArrayList<Corner> cities = this.getPotentialCities();
            int n=r.nextInt(cities.size());
            cities.get(n).setCity(this);
            getInventory().cutCityMaterial();
        }

        while(this.getInventory().canBuildSettelment() && !getPotentialSettelments().isEmpty()){
            ArrayList<Corner> cities = this.getPotentialSettelments();
            int n=r.nextInt(cities.size());
            cities.get(n).setSettlement(this);
            getInventory().cutSettelmentMaterial();
        }
        while(this.getInventory().canBuildRoad() && !getPotentialRoads().isEmpty()){
            ArrayList<Side> roads = this.getPotentialRoads();
            int n=r.nextInt(roads.size());
            roads.get(n).setRoad(this);
            getInventory().cutRoadMaterial();
        }
        if(this.getInventory().canBuyDev()){
            while(this.getInventory().canBuyDev()) buyDevCard();
        }else{
            //TODO
            //use devs
        }
        sv.skip();
    }

    public void placeRobberStrategy(){}
    public void StealStrategy(){}
    public void MonopolyStrategy(){}
    public void ExpansionStrategy(){}
    public void ProgressStrategy(){}
    public void VPStrategy(){}

    public void applyStrategy(FirstMoveState st) {
        ArrayList<Corner> targetCorners=new ArrayList<>();

        for (Corner corner : st.getSettings().map.getCorners()) {
            if(corner.isBuildable()){
                targetCorners.add(corner);
            }
        }

        if(targetCorners.isEmpty()) throw new RuntimeException("runtime exception");
        Random random = new Random();
        int r=random.nextInt(targetCorners.size());
        targetCorners.get(r).ForceSetSettlement(this);
        if(st.getRessources)targetCorners.get(r).harnessAdjascentTiles();
        st.getGsm().removeState();
    }

    public void applyStrategy(SecondMoveState st) {
        ArrayList<Side> targetSides=new ArrayList<>();

        for(Corner c: this.settelments){
            if(c.isIsolated()) {
                for (Side side : c.getAdjascentSides()) {
                    targetSides.add(side);
                }
            }
        }

        if(targetSides.isEmpty()) throw new RuntimeException("runtime exception");


        Random random = new Random();
        int r=random.nextInt(targetSides.size());
        targetSides.get(r).setRoad(this);
        st.getGsm().removeState();
    }

    public void applyStrategy(GameState st) {}

}

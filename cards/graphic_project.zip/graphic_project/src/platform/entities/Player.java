package platform.entities;

import platform.GameSettings;
import platform.entities.buildings.City;
import platform.observers.Observer;
import platform.render.Model;

import platform.states.*;
import platform.utils.Card;
import platform.utils.Ressources;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public abstract class Player {

    public String name;
    Model module;
    private Player next;
    private Color color;
    private int VP;
    private int robberUsed;
    private int roadsBuilt;
    private boolean hasLongestRoad;
    private boolean hasLArgestArmy;
    private Inventory inventory;


    private ArrayList<Observer> observers=new ArrayList<>();
    public ArrayList<Corner> settelments=new ArrayList<>();
    public ArrayList<Side> roads=new ArrayList<>();


    public Player(String name, Color color) {
        this.color=color;
        this.name = name;
        this.VP=0;
        this.robberUsed=0;
        this.hasLongestRoad=false;
        this.hasLArgestArmy=false;
        this.inventory=new Inventory();
        this.roadsBuilt=0;
    }
    public void buyDevCard(){
        Random r =new Random();
        int probability=r.nextInt(25);
        if(probability<=13) getInventory().addCard(new Card(Card.robber));
        else if(probability<=18) getInventory().addCard(new Card(Card.vp));
        else if(probability<=20) getInventory().addCard(new Card(Card.progress));
        else if(probability<=22) getInventory().addCard(new Card(Card.expansion));
        else getInventory().addCard(new Card(Card.monopoly));
        inventory.cutDevMaterial();
    }
    public void giveCardTo(Player player){
        if(inventory.noResCards()>0) {
            Ressources r = inventory.getRandomCard();
            player.getInventory().addRessource(r);
        }
    }


    //longest road______________________________
    private boolean isValid(Side s, boolean[] visited){
        return roads.contains(s) && !visited[roads.indexOf(s)];
    }
    private static boolean[] CopyOf(boolean[] t){
        boolean[] res=new boolean[t.length];
        for (int i=0;i<t.length;i++)
            res[i]=t[i];
        return res;
    }
    public int calculateLongestRoad(){
        int longest_road=0;
        for(Side chemin:roads){
            boolean[] visited=new boolean[roads.size()];
            longest_road=Math.max(longest_road,longestItineary(chemin,visited));
        }
        return longest_road;
    }
    public int longestItineary(Side side, boolean[] visited){
        visited[roads.indexOf(side)]=true;
        ArrayList<Side> next_sides=new ArrayList<>();
        ArrayList<Corner> next_corners=side.getAdjascentCorners();

        for(Corner c : next_corners) {
            if (!c.hasSettlement() || settelments.contains(c.getBuilding())) {
                ArrayList<Side> tmp = c.getAdjascentSides();
                for (Side s : tmp) {
                    if (isValid(s, visited)) next_sides.add(s);
                }
            }
        }
        int res=1;
        int longest_itineary=0;
        for(Side s : next_sides){
            longest_itineary=Math.max(longest_itineary,longestItineary(s,CopyOf(visited)));
        }
        return res+longest_itineary;
    }
    //__________________________________________

    public ArrayList<Corner> getPotentialSettelments(){
        ArrayList<Corner> ps=new ArrayList<>();
        for(Side s : roads){
            if(s.corner_1.isBuildable() && !ps.contains(s.corner_1))ps.add(s.corner_1);
            if(s.corner_2.isBuildable() && !ps.contains(s.corner_2))ps.add(s.corner_2);
        }
        return ps;
    }
    public ArrayList<Side> getPotentialRoads(){
        ArrayList<Side> pr=new ArrayList<>();
        for(Corner c:settelments){
            for(Side s:c.getAdjascentSides()){
                if(s.isBuildable() && !pr.contains(s)) pr.add(s);
            }
        }

        for(Side s:roads){
            for(Side s_1:s.get_future_roads_from_this_road(this)){
                if(!pr.contains(s_1)) pr.add(s_1);
            }
        }
        return pr;
    }
    public ArrayList<Corner> getPotentialCities(){
        ArrayList<Corner> pc=new ArrayList<>();
        for(Corner c:settelments){
            if(c.getBuilding()!=null && !(c.getBuilding() instanceof City)) pc.add(c);
        }
        return pc;
    }

    //__________________________________________

    public abstract boolean isHuman();
    public abstract boolean isBot();
    public abstract void applyStrategy(MainState st);
    public abstract void applyStrategy(FirstMoveState st);
    public abstract void applyStrategy(SecondMoveState st);
    public abstract void applyStrategy(GameState st);


    public Color getColor() {return color;}
    public void setColor(Color color) {this.color = color;}

    public Inventory getInventory() {return inventory;}
    public Model getModule() {return module;}
    public Player getNext() {return next;}
    public void setNext(Player next) {this.next = next;}


    public void addObs(Observer ob){
        this.observers.add(ob);
    }
    public void detachObs(Observer ob){
        this.observers.remove(ob);
    }
    public void inform(){
        for(Observer ob : observers) ob.inform();
    }



    public int getVP() {return VP;}
    public void increaseVP(int n) {this.VP =this.VP+n;inform();}

    public int getRobberUsed() {return robberUsed;}
    public boolean hasLArgestArmy() {return hasLArgestArmy;}
    public void setLArgestArmy(boolean hasLArgestArmy) {
        if(this.hasLArgestArmy){
            if(! hasLArgestArmy) increaseVP(-2);
        }else{
            if(hasLArgestArmy) increaseVP(2);
        }
        this.hasLArgestArmy = hasLArgestArmy;
    }

    public boolean hasLongestRoad() {return hasLongestRoad;}
    public void setLongestRoad(boolean hasLongestRoad) {
        if(this.hasLongestRoad){
            if(! hasLongestRoad) increaseVP(-2);
        }else{
            if(hasLongestRoad) increaseVP(2);
        }
        this.hasLongestRoad = hasLongestRoad;
    }
    public int getRoadsBuilt() {return roadsBuilt;}
    public void setRoadsBuilt(int roadsBuilt) {this.roadsBuilt = roadsBuilt;}

    public void set(Player p){
        p.next=next;
        p.VP=VP;
        p.robberUsed=robberUsed;
        p.roadsBuilt=roadsBuilt;
        p.hasLongestRoad=hasLongestRoad;
        p.hasLArgestArmy=hasLArgestArmy;
        p.inventory=inventory;
        p.observers=observers;
        p.settelments=settelments;
        for (Corner c : p.settelments) c.getBuilding().setOwner(p);
        p.roads=roads;
        for (Side s : p.roads) s.getBuilding().setOwner(p);
    }
}


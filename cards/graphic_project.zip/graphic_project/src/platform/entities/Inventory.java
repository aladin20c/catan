package platform.entities;


import platform.utils.Card;
import platform.utils.Ressources;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;


public class Inventory {
    public final static int RESSOURCECAPACITY=5;
    public final static int CARDCAPACITY=5;

    private HashMap<Ressources,Integer> ressources;
    private HashMap<Card,Integer> cards;

    public Inventory() {
        ressources=new HashMap<>();
        ressources.put(Ressources.WHEAT,0);
        ressources.put(Ressources.LUMBER,0);
        ressources.put(Ressources.BRICK,0);
        ressources.put(Ressources.ORE,0);
        ressources.put(Ressources.SHEEP,0);
        cards=new HashMap<>();
    }


    public void addCard(Card r){
        int already_exist=cards.getOrDefault(r,0);
        cards.put(r,already_exist+1);
    }
    public void removeCard(Card r){
        int already_exist=cards.getOrDefault(r,0);
        if(already_exist<=1){
            cards.remove(r);
        }
        else cards.put(r,already_exist-1);
    }
    public boolean containsCard(Card r){
        int already_exist=cards.getOrDefault(r,0);
        return already_exist>=1;
    }
    public int count(Card r){
        return cards.getOrDefault(r,0);
    }

    public void addRessource(Ressources r){
        int already_exist=ressources.getOrDefault(r,0);
        ressources.put(r,already_exist+1);
    }
    public void addRessource(Ressources r,int n){
        int already_exist=ressources.getOrDefault(r,0);
        ressources.put(r,already_exist+n);
    }
    public void removeRessource(Ressources r){
        int already_exist=ressources.getOrDefault(r,0);
        if(already_exist==0) return;
        else ressources.put(r,already_exist-1);
    }
    public void removeRessource(Ressources r,int n){
        int already_exist=ressources.getOrDefault(r,0);
        if(already_exist<n) return;
        else ressources.put(r,already_exist-n);
    }
    public boolean containsRessource(Ressources r){
        int already_exist=ressources.getOrDefault(r,0);
        return already_exist>=1;
    }
    public boolean containsRessource(Ressources r,int n){
        int already_exist=ressources.getOrDefault(r,0);
        return already_exist>=n;
    }
    public Set<Card> getExistingCards(){
        return  cards.keySet();
    }
    public Ressources getRandomCard(){
        Random random=new Random();
        int r=random.nextInt(noResCards())+1;
        int acc=0;
        for (Ressources key : ressources.keySet()) {
            acc+=ressources.get(key);
            if(r<=acc) {
                removeRessource(key);
                return key;
            }
        }
        throw new RuntimeException("this is not supposed to happen");
    }


    public int noResCards(){
        return ressources.get(Ressources.WHEAT)+ressources.get(Ressources.SHEEP)+ressources.get(Ressources.ORE)+ressources.get(Ressources.LUMBER)+ressources.get(Ressources.BRICK);
    }
    public boolean canBuyDev(){
        return containsRessource(Ressources.ORE) && containsRessource(Ressources.WHEAT) && containsRessource(Ressources.SHEEP);
    }
    public boolean canBuildRoad(){
        return containsRessource(Ressources.LUMBER) && containsRessource(Ressources.BRICK);
    }
    public boolean canBuildSettelment(){
        return containsRessource(Ressources.LUMBER) && containsRessource(Ressources.BRICK) && containsRessource(Ressources.WHEAT) && containsRessource(Ressources.SHEEP);
    }
    public boolean canBuildCity(){
        return containsRessource(Ressources.WHEAT,2) && containsRessource(Ressources.ORE,3);
    }
    public void cutRoadMaterial(){
        removeRessource(Ressources.LUMBER);
        removeRessource(Ressources.BRICK);
    }
    public void cutSettelmentMaterial(){
        removeRessource(Ressources.LUMBER);
        removeRessource(Ressources.BRICK);
        removeRessource(Ressources.WHEAT);
        removeRessource(Ressources.SHEEP);
    }
    public void cutCityMaterial(){
        removeRessource(Ressources.WHEAT,2);
        removeRessource(Ressources.ORE,3);
    }
    public void cutDevMaterial(){
        removeRessource(Ressources.ORE,1);
        removeRessource(Ressources.WHEAT,1);
        removeRessource(Ressources.ORE,1);
    }
    public int count(Ressources r){
        return ressources.getOrDefault(r,0);
    }



}